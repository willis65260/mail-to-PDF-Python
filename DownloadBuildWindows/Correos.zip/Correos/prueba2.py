import os

print(os.listdir("/Program Files/wkhtmltopdf/bin/wkhtmltopdf.exe"))


ruta = open('PalabrasClave.txt', 'r')
keywords = ruta.read().split(",")
ruta.close()

print(keywords)